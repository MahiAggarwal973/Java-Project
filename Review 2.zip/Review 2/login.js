document.querySelector("form").addEventListener("submit", function (e) {
        const email = document.getElementById("email").value;
        const password = document.getElementById("password").value;
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

        if (!emailRegex.test(email)) {
            alert("Please enter a valid email.");
            e.preventDefault();
        }

        if (password.length < 6) {
            alert("Password must be at least 6 characters.");
            e.preventDefault();
        }
    });
