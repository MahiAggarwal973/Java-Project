document.querySelector("form").addEventListener("submit", function (e) {
        const email = document.getElementById("email").value.trim();
        const newPassword = document.getElementById("new-password").value.trim();
        const confirmPassword = document.getElementById("confirm-password").value.trim();

        // Email Regex for Validation
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

        // Email Validation
        if (!emailRegex.test(email)) {
            alert("Please enter a valid email address.");
            e.preventDefault();
            return;
        }

        // Password Validation
        if (newPassword.length < 6) {
            alert("New Password must be at least 6 characters long.");
            e.preventDefault();
            return;
        }

        // Confirm Password Match
        if (newPassword !== confirmPassword) {
            alert("Passwords do not match.");
            e.preventDefault();
        }
    });
