// Confirmation for actions
document.querySelectorAll('.list-group-item').forEach((item) => {
    item.addEventListener('click', function (e) {
        if (this.textContent.includes('Delete')) {
            if (!confirm('Are you sure you want to delete this item?')) {
                e.preventDefault();
            }
        }
    });
});
