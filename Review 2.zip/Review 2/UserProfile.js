document.querySelector("form").addEventListener("submit", function (e) {
        const name = document.getElementById("name").value.trim();
        const email = document.getElementById("email").value.trim();
        const phone = document.getElementById("phone").value.trim();
        const password = document.getElementById("password").value.trim();
        
        // Email Regex for Validation
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        const phoneRegex = /^[0-9]{10}$/;

        // Name Validation
        if (name.length < 3) {
            alert("Full Name must be at least 3 characters long.");
            e.preventDefault();
            return;
        }

        // Email Validation
        if (!emailRegex.test(email)) {
            alert("Please enter a valid email address.");
            e.preventDefault();
            return;
        }

        // Phone Validation (if not empty)
        if (phone && !phoneRegex.test(phone)) {
            alert("Phone Number must be 10 digits.");
            e.preventDefault();
            return;
        }

        // Password Validation
        if (password && password.length < 6) {
            alert("Password must be at least 6 characters long.");
            e.preventDefault();
        }
    });
