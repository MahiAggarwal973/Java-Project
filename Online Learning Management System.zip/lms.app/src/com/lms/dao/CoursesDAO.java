package com.lms.dao;

import com.lms.utils.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class CoursesDAO {

    // Add a new course
    public void addCourse(String title, String description, int teacherId) {
        String sql = "INSERT INTO Courses (title, description, teacher_id) VALUES (?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, title);
            stmt.setString(2, description);
            stmt.setInt(3, teacherId);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Retrieve all courses
    public void getCourses() {
        String sql = "SELECT * FROM Courses";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                System.out.println("Course ID: " + rs.getInt("id"));
                System.out.println("Title: " + rs.getString("title"));
                System.out.println("Description: " + rs.getString("description"));
                System.out.println("Teacher ID: " + rs.getInt("teacher_id"));
                System.out.println("----");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
