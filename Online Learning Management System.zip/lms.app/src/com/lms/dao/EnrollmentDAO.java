package com.lms.dao;

import com.lms.utils.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class EnrollmentDAO {

    // Add a new enrollment
    public void addEnrollment(int studentId, int courseId) {
        String sql = "INSERT INTO Enrollments (student_id, course_id) VALUES (?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, studentId);
            stmt.setInt(2, courseId);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Retrieve all enrollments
    public void getEnrollments() {
        String sql = "SELECT e.id, u.name AS student_name, c.title AS course_title FROM Enrollments e " +
                     "JOIN Users u ON e.student_id = u.id " +
                     "JOIN Courses c ON e.course_id = c.id";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                System.out.println("Enrollment ID: " + rs.getInt("id"));
                System.out.println("Student Name: " + rs.getString("student_name"));
                System.out.println("Course Title: " + rs.getString("course_title"));
                System.out.println("----");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
